@echo off
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle was not found. Install Gradle 8.12+ and Java 21, then rerun this file.
  pause
  exit /b 1
)
gradle build
if errorlevel 1 exit /b %errorlevel%
echo.
echo Build complete: build\libs\horrormod-1.0.0.jar
pause
