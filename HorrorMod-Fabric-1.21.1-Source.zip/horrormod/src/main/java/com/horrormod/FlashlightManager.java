package com.horrormod;

import com.horrormod.entity.HorrorMob;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.LightBlock;
import net.minecraft.entity.LivingEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Server-side flashlight: moves one invisible light block to where the player aims, and scares horror mobs in the beam. */
public class FlashlightManager {
    private static final Set<UUID> ON = new HashSet<>();
    private static final Map<UUID, Placed> PLACED = new HashMap<>();

    private record Placed(ServerWorld world, BlockPos pos) {}

    public static boolean toggle(UUID id) {
        if (ON.remove(id)) {
            clear(id);
            return false;
        }
        ON.add(id);
        return true;
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(FlashlightManager::tick);
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            UUID id = handler.getPlayer().getUuid();
            clear(id);
            ON.remove(id);
        });
    }

    private static void clear(UUID id) {
        Placed p = PLACED.remove(id);
        if (p != null && p.world().getBlockState(p.pos()).isOf(Blocks.LIGHT)) {
            p.world().setBlockState(p.pos(), Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
        }
    }

    private static void tick(MinecraftServer server) {
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            UUID id = p.getUuid();
            boolean holding = p.getMainHandStack().isOf(ModItems.FLASHLIGHT) || p.getOffHandStack().isOf(ModItems.FLASHLIGHT);
            if (!ON.contains(id) || !holding || p.isSpectator()) {
                clear(id);
                continue;
            }
            ServerWorld w = p.getServerWorld();
            List<LivingEntity> near = w.getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(16), e -> e instanceof HorrorMob);

            // Flicker when something is close
            if (!near.isEmpty() && w.random.nextInt(8) == 0) {
                clear(id);
                continue;
            }

            // Scare things caught in the beam
            if (server.getTicks() % 4 == 0) {
                for (LivingEntity e : near) {
                    if (LookUtil.isLookingAt(p, e, 0.92)) ((HorrorMob) e).onFlashlight(p);
                }
            }

            // Move the light
            Vec3d eye = p.getEyePos();
            Vec3d look = p.getRotationVec(1.0f);
            HitResult hit = p.raycast(14, 1.0f, false);
            BlockPos target;
            if (hit.getType() == HitResult.Type.BLOCK) {
                BlockHitResult bh = (BlockHitResult) hit;
                target = bh.getBlockPos().offset(bh.getSide());
            } else {
                target = BlockPos.ofFloored(eye.add(look.multiply(14)));
            }
            Placed prev = PLACED.get(id);
            if (prev != null && prev.world() == w && prev.pos().equals(target) && w.getBlockState(target).isOf(Blocks.LIGHT)) continue;
            clear(id);
            if (!w.getBlockState(target).isAir()) continue;
            w.setBlockState(target, Blocks.LIGHT.getDefaultState().with(LightBlock.LEVEL_15, 14), Block.NOTIFY_LISTENERS);
            PLACED.put(id, new Placed(w, target));
        }
    }
}
