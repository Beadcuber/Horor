package com.horrormod;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class ModItems {
    public static final Item FLASHLIGHT = reg("flashlight", new FlashlightItem(new Item.Settings().maxCount(1)));
    public static final Item CAVE_DWELLER_EGG = reg("cave_dweller_spawn_egg",
            new SpawnEggItem(ModEntities.CAVE_DWELLER, 0x1b1b1b, 0xb0b8b0, new Item.Settings()));
    public static final Item HEROBRINE_EGG = reg("herobrine_spawn_egg",
            new SpawnEggItem(ModEntities.HEROBRINE, 0x00a0a0, 0xffffff, new Item.Settings()));
    public static final Item FOG_STALKER_EGG = reg("fog_stalker_spawn_egg",
            new SpawnEggItem(ModEntities.FOG_STALKER, 0x0f0f12, 0xc80000, new Item.Settings()));

    private static Item reg(String name, Item item) {
        return Registry.register(Registries.ITEM, HorrorMod.id(name), item);
    }

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> e.add(FLASHLIGHT));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(e -> {
            e.add(CAVE_DWELLER_EGG);
            e.add(HEROBRINE_EGG);
            e.add(FOG_STALKER_EGG);
        });
    }
}
