package com.horrormod;

import com.horrormod.entity.CaveDwellerEntity;
import com.horrormod.entity.FogStalkerEntity;
import com.horrormod.entity.HerobrineEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class ModEntities {
    public static final EntityType<CaveDwellerEntity> CAVE_DWELLER = reg("cave_dweller",
            EntityType.Builder.create(CaveDwellerEntity::new, SpawnGroup.MONSTER).dimensions(0.6f, 1.95f).maxTrackingRange(10));
    public static final EntityType<HerobrineEntity> HEROBRINE = reg("herobrine",
            EntityType.Builder.create(HerobrineEntity::new, SpawnGroup.MONSTER).dimensions(0.6f, 1.95f).maxTrackingRange(16));
    public static final EntityType<FogStalkerEntity> FOG_STALKER = reg("fog_stalker",
            EntityType.Builder.create(FogStalkerEntity::new, SpawnGroup.MONSTER).dimensions(0.6f, 2.6f).maxTrackingRange(12));

    private static <T extends Entity> EntityType<T> reg(String name, EntityType.Builder<T> builder) {
        return Registry.register(Registries.ENTITY_TYPE, HorrorMod.id(name), builder.build(name));
    }

    public static void register() {
        FabricDefaultAttributeRegistry.register(CAVE_DWELLER, CaveDwellerEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(HEROBRINE, HerobrineEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(FOG_STALKER, FogStalkerEntity.createAttributes());
    }
}
