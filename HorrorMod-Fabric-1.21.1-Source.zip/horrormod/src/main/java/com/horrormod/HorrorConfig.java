package com.horrormod;

/** Global scare multiplier. 0 = off, 1 = default, higher = more frequent. Change in-game with /horror intensity. */
public class HorrorConfig {
    public static volatile double intensity = 1.0;
}
