package com.horrormod.client;

import com.horrormod.HorrorMod;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.util.Identifier;

public class HorrorRenderer<T extends MobEntity> extends MobEntityRenderer<T, BipedEntityModel<T>> {
    private final Identifier texture;
    private final float scale;

    public HorrorRenderer(EntityRendererFactory.Context ctx, String textureName, float scale) {
        super(ctx, new BipedEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE)), 0.5f);
        this.texture = HorrorMod.id("textures/entity/" + textureName + ".png");
        this.scale = scale;
    }

    @Override
    public Identifier getTexture(T entity) {
        return texture;
    }

    @Override
    protected void scale(T entity, MatrixStack matrices, float amount) {
        matrices.scale(scale, scale, scale);
    }
}
