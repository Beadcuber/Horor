package com.horrormod.client;

import com.horrormod.ModEntities;
import com.horrormod.entity.HorrorMob;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.world.World;
import org.lwjgl.glfw.GLFW;

public class HorrorClient implements ClientModInitializer {
    private static KeyBinding fogKey;
    private static boolean nearHorror = false;

    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.CAVE_DWELLER, ctx -> new HorrorRenderer<>(ctx, "cave_dweller", 1.0f));
        EntityRendererRegistry.register(ModEntities.HEROBRINE, ctx -> new HorrorRenderer<>(ctx, "herobrine", 1.0f));
        EntityRendererRegistry.register(ModEntities.FOG_STALKER, ctx -> new HorrorRenderer<>(ctx, "fog_stalker", 1.3f));

        fogKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.horrormod.fog", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, "key.category.horrormod"));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (fogKey.wasPressed()) {
                FogState.enabled = !FogState.enabled;
                if (mc.player != null) mc.player.sendMessage(Text.literal("Horror fog " + (FogState.enabled ? "ON" : "OFF")), true);
            }
            updateFog(mc);
        });
    }

    private static void updateFog(MinecraftClient mc) {
        ClientWorld w = mc.world;
        float target = 0f;
        if (w != null && mc.player != null && FogState.enabled && w.getRegistryKey() == World.OVERWORLD) {
            long t = w.getTimeOfDay() % 24000;
            boolean night = t >= 12500 && t <= 23500;
            int light = w.getLightLevel(mc.player.getBlockPos());
            float base = night ? 0.7f : 0.25f;
            if (light < 5) base = Math.max(base, 0.6f);
            if (w.isRaining()) base += 0.15f;

            if (mc.player.age % 10 == 0) {
                nearHorror = !w.getEntitiesByClass(MobEntity.class, mc.player.getBoundingBox().expand(40), e -> e instanceof HorrorMob).isEmpty();
            }
            if (nearHorror) base = 1.0f;
            target = Math.min(1f, base);

            if (nearHorror && mc.player.age % 40 == 0) {
                mc.player.playSound(SoundEvents.ENTITY_WARDEN_HEARTBEAT, 1.0f, 1.0f);
            }
        }
        FogState.intensity += (target - FogState.intensity) * 0.02f;
    }
}
