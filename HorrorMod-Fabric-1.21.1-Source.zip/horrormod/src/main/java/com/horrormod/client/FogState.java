package com.horrormod.client;

public class FogState {
    public static boolean enabled = true;
    public static float intensity = 0f;
    public static float[] baseColor = {1f, 1f, 1f};
}
