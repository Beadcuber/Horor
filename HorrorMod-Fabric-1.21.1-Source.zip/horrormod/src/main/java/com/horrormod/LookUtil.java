package com.horrormod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

public class LookUtil {
    /** True if viewer is looking toward target (dot threshold ~0.97 = tight, 0.6 = wide) with a clear line of sight. */
    public static boolean isLookingAt(LivingEntity viewer, Entity target, double threshold) {
        Vec3d look = viewer.getRotationVec(1.0f).normalize();
        Vec3d to = target.getEyePos().subtract(viewer.getEyePos()).normalize();
        return look.dotProduct(to) > threshold && viewer.canSee(target);
    }
}
