package com.horrormod;

import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;

public class HorrorMod implements ModInitializer {
    public static final String MOD_ID = "horrormod";

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModEntities.register();
        ModItems.register();
        FlashlightManager.register();
        HorrorEvents.register();
        HorrorCommands.register();
    }
}
