package com.horrormod.entity;

import com.horrormod.LookUtil;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

/** Tall shape in the fog. Freezes while anyone is looking at it, sprints when nobody is. */
public class FogStalkerEntity extends HostileEntity implements HorrorMob {
    public FogStalkerEntity(EntityType<? extends FogStalkerEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 30.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.45)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 8.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 40.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new MeleeAttackGoal(this, 1.2, false));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.7));
        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, false));
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient) return;
        boolean seen = false;
        for (PlayerEntity p : getWorld().getPlayers()) {
            if (!p.isSpectator() && distanceTo(p) < 48 && LookUtil.isLookingAt(p, this, 0.6)) {
                seen = true;
                break;
            }
        }
        setAiDisabled(seen);
        if (seen) setVelocity(0, getVelocity().y, 0);
        if (age > 9000 && getTarget() == null) discard();
    }

    @Override
    public void onFlashlight(ServerPlayerEntity player) {
        addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 2));
        addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 60, 0));
    }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ENTITY_PHANTOM_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.ENTITY_ELDER_GUARDIAN_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_ELDER_GUARDIAN_DEATH; }
}
