package com.horrormod.entity;

import net.minecraft.server.network.ServerPlayerEntity;

/** Marker for mobs that react to the flashlight and drive the client fog. */
public interface HorrorMob {
    void onFlashlight(ServerPlayerEntity player);
}
