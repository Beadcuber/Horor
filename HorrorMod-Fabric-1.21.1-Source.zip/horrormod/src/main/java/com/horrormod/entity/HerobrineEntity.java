package com.horrormod.entity;

import com.horrormod.LookUtil;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

/** Stands in the distance with white eyes and watches you. Vanishes if stared at, approached, hit, or lit up. */
public class HerobrineEntity extends PathAwareEntity implements HorrorMob {
    private int stared = 0;
    private int lonely = 0;

    public HerobrineEntity(EntityType<? extends HerobrineEntity> type, World world) {
        super(type, world);
        this.setInvulnerable(true);
        this.setPersistent();
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 20.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new LookAtEntityGoal(this, PlayerEntity.class, 64.0f, 1.0f));
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient) return;
        PlayerEntity p = getWorld().getClosestPlayer(this, 64);
        if (p == null) {
            if (++lonely > 200) discard();
            return;
        }
        lonely = 0;
        if (LookUtil.isLookingAt(p, this, 0.97)) stared++; else stared = Math.max(0, stared - 1);
        if (stared > 60 || distanceTo(p) < 6 || age > 2400) vanish();
    }

    private void vanish() {
        if (getWorld() instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 1, getZ(), 30, 0.3, 0.8, 0.3, 0.01);
            sw.playSound(null, getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.AMBIENT, 0.7f, 0.4f);
        }
        discard();
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (source.isIn(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.damage(source, amount);
        if (!getWorld().isClient) vanish();
        return false;
    }

    @Override public void onFlashlight(ServerPlayerEntity player) { vanish(); }
    @Override public boolean isPushable() { return false; }
}
