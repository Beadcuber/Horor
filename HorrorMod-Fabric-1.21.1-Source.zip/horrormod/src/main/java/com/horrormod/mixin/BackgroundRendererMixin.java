package com.horrormod.mixin;

import com.horrormod.client.FogState;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.client.render.CameraSubmersionType;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(BackgroundRenderer.class)
public class BackgroundRendererMixin {
    private static final float[] DARK = {0.035f, 0.04f, 0.045f};

    @Inject(method = "render", at = @At("TAIL"))
    private static void horrormod$color(Camera camera, float tickDelta, ClientWorld world, int viewDistance, float skyDarkness, CallbackInfo ci) {
        float i = FogState.intensity;
        if (!FogState.enabled || i <= 0.01f || camera.getSubmersionType() != CameraSubmersionType.NONE) return;
        float[] c = RenderSystem.getShaderFogColor();
        FogState.baseColor = new float[]{c[0], c[1], c[2]};
        float r = MathHelper.lerp(i, c[0], DARK[0]);
        float g = MathHelper.lerp(i, c[1], DARK[1]);
        float b = MathHelper.lerp(i, c[2], DARK[2]);
        RenderSystem.clearColor(r, g, b, 0.0f);
        RenderSystem.setShaderFogColor(r, g, b);
    }

    @Inject(method = "applyFog", at = @At("TAIL"))
    private static void horrormod$fog(Camera camera, BackgroundRenderer.FogType fogType, float viewDistance, boolean thickFog, float tickDelta, CallbackInfo ci) {
        float i = FogState.intensity;
        if (!FogState.enabled || i <= 0.01f) return;
        if (fogType != BackgroundRenderer.FogType.FOG_TERRAIN) return;
        if (camera.getSubmersionType() != CameraSubmersionType.NONE) return;
        RenderSystem.setShaderFogStart(MathHelper.lerp(i, RenderSystem.getShaderFogStart(), 2.0f));
        RenderSystem.setShaderFogEnd(MathHelper.lerp(i, RenderSystem.getShaderFogEnd(), 16.0f));
        float r = MathHelper.lerp(i, FogState.baseColor[0], DARK[0]);
        float g = MathHelper.lerp(i, FogState.baseColor[1], DARK[1]);
        float b = MathHelper.lerp(i, FogState.baseColor[2], DARK[2]);
        RenderSystem.setShaderFogColor(r, g, b);
    }
}
