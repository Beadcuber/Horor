package com.horrormod;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.CommandSource;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/** /horror spawn <dweller|herobrine|stalker> | /horror event | /horror intensity <0-10> */
public class HorrorCommands {
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, env) ->
                dispatcher.register(CommandManager.literal("horror")
                        .requires(s -> s.hasPermissionLevel(2))
                        .then(CommandManager.literal("spawn")
                                .then(CommandManager.argument("type", StringArgumentType.word())
                                        .suggests((c, b) -> CommandSource.suggestMatching(new String[]{"dweller", "herobrine", "stalker"}, b))
                                        .executes(ctx -> {
                                            ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                                            String t = StringArgumentType.getString(ctx, "type");
                                            EntityType<? extends MobEntity> type = switch (t) {
                                                case "dweller" -> ModEntities.CAVE_DWELLER;
                                                case "herobrine" -> ModEntities.HEROBRINE;
                                                case "stalker" -> ModEntities.FOG_STALKER;
                                                default -> null;
                                            };
                                            if (type == null) {
                                                ctx.getSource().sendError(Text.literal("Unknown type. Use dweller, herobrine or stalker."));
                                                return 0;
                                            }
                                            boolean ok = HorrorEvents.spawn(p.getServerWorld(), p, type, 14, 22);
                                            if (!ok) ctx.getSource().sendError(Text.literal("Couldn't spawn (already one nearby, or no space)."));
                                            return ok ? 1 : 0;
                                        })))
                        .then(CommandManager.literal("event").executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                            HorrorEvents.randomEvent(p.getServerWorld(), p);
                            return 1;
                        }))
                        .then(CommandManager.literal("intensity")
                                .then(CommandManager.argument("value", DoubleArgumentType.doubleArg(0, 10))
                                        .executes(ctx -> {
                                            HorrorConfig.intensity = DoubleArgumentType.getDouble(ctx, "value");
                                            ctx.getSource().sendFeedback(() -> Text.literal("Horror intensity: " + HorrorConfig.intensity), true);
                                            return 1;
                                        })))));
    }
}
