package com.horrormod;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Random spawns and scares, rolled once per second per player. Scale with /horror intensity. */
public class HorrorEvents {
    private static final Map<UUID, Integer> STEPS = new HashMap<>();
    private static final Map<UUID, Long> LEAVE_AT = new HashMap<>();

    public static void register() {
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            if (world.getTime() % 20 != 0) return;
            for (ServerPlayerEntity p : world.getPlayers()) {
                if (!p.isSpectator()) tickPlayer(world, p);
            }
        });
    }

    private static void tickPlayer(ServerWorld w, ServerPlayerEntity p) {
        double I = HorrorConfig.intensity;
        if (I <= 0) return;
        Random r = w.random;
        UUID id = p.getUuid();
        BlockPos pos = p.getBlockPos();
        int light = w.getLightLevel(pos);
        boolean sky = w.isSkyVisible(pos);

        Integer steps = STEPS.get(id);
        if (steps != null) {
            footstep(w, p, steps);
            if (steps <= 0) STEPS.remove(id); else STEPS.put(id, steps - 1);
        }
        Long leave = LEAVE_AT.get(id);
        if (leave != null && w.getTime() >= leave) {
            p.sendMessage(Text.translatable("multiplayer.player.left", "Herobrine").formatted(Formatting.YELLOW));
            LEAVE_AT.remove(id);
        }

        if (r.nextDouble() < 0.012 * I) ambientSound(w, p);
        if (light <= 4 && !sky && r.nextDouble() < 0.010 * I) spawn(w, p, ModEntities.CAVE_DWELLER, 22, 32);
        if (r.nextDouble() < 0.0025 * I) spawn(w, p, ModEntities.HEROBRINE, 26, 40);
        if (light <= 7 && r.nextDouble() < 0.006 * I) spawn(w, p, ModEntities.FOG_STALKER, 24, 34);
        if (r.nextDouble() < 0.0015 * I) fakeJoin(w, p);
        if (r.nextDouble() < 0.003 * I) STEPS.put(id, 5);
        if (r.nextDouble() < 0.0008 * I) removeTorch(w, p);
        if (light <= 3 && !sky && r.nextDouble() < 0.004 * I) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 120, 0, false, false));
        }
    }

    public static void randomEvent(ServerWorld w, ServerPlayerEntity p) {
        switch (w.random.nextInt(5)) {
            case 0 -> ambientSound(w, p);
            case 1 -> fakeJoin(w, p);
            case 2 -> STEPS.put(p.getUuid(), 5);
            case 3 -> removeTorch(w, p);
            default -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 120, 0, false, false));
        }
    }

    private static Vec3d behind(ServerPlayerEntity p, double dist) {
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d flat = new Vec3d(look.x, 0, look.z).normalize();
        return p.getPos().subtract(flat.multiply(dist));
    }

    private static void ambientSound(ServerWorld w, ServerPlayerEntity p) {
        SoundEvent[] sounds = {
                SoundEvents.AMBIENT_CAVE.value(), SoundEvents.ENTITY_ENDERMAN_STARE, SoundEvents.ENTITY_WARDEN_HEARTBEAT,
                SoundEvents.BLOCK_WOODEN_DOOR_OPEN, SoundEvents.ENTITY_ELDER_GUARDIAN_CURSE, SoundEvents.ENTITY_GHAST_WARN,
                SoundEvents.ENTITY_PHANTOM_AMBIENT, SoundEvents.ENTITY_CREEPER_PRIMED, SoundEvents.ENTITY_WITCH_AMBIENT,
                SoundEvents.BLOCK_CHEST_OPEN
        };
        SoundEvent s = sounds[w.random.nextInt(sounds.length)];
        Vec3d at = behind(p, 6);
        w.playSound(null, at.x, at.y, at.z, s, SoundCategory.AMBIENT, 1.0f, 0.6f + w.random.nextFloat() * 0.5f);
    }

    private static void footstep(ServerWorld w, ServerPlayerEntity p, int left) {
        Vec3d at = behind(p, 1.5 + left);
        SoundEvent s = (left % 2 == 0) ? SoundEvents.BLOCK_STONE_STEP : SoundEvents.BLOCK_GRAVEL_STEP;
        w.playSound(null, at.x, at.y, at.z, s, SoundCategory.HOSTILE, 1.5f, 0.7f);
    }

    private static void fakeJoin(ServerWorld w, ServerPlayerEntity p) {
        p.sendMessage(Text.translatable("multiplayer.player.joined", "Herobrine").formatted(Formatting.YELLOW));
        LEAVE_AT.put(p.getUuid(), w.getTime() + 100 + w.random.nextInt(200));
    }

    private static void removeTorch(ServerWorld w, ServerPlayerEntity p) {
        for (BlockPos b : BlockPos.iterateOutwards(p.getBlockPos(), 8, 4, 8)) {
            if (w.getBlockState(b).isOf(Blocks.TORCH) || w.getBlockState(b).isOf(Blocks.WALL_TORCH)) {
                w.setBlockState(b, Blocks.AIR.getDefaultState());
                w.playSound(null, b, SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.BLOCKS, 0.8f, 0.8f);
                return;
            }
        }
    }

    /** Spawns the mob min..max blocks from the player, unless one already exists nearby. */
    public static boolean spawn(ServerWorld w, ServerPlayerEntity p, EntityType<? extends MobEntity> type, int min, int max) {
        Box box = p.getBoundingBox().expand(100);
        if (!w.getEntitiesByType(type, box, e -> true).isEmpty()) return false;
        for (int i = 0; i < 16; i++) {
            double a = w.random.nextDouble() * Math.PI * 2;
            double d = min + w.random.nextDouble() * (max - min);
            int x = MathHelper.floor(p.getX() + Math.cos(a) * d);
            int z = MathHelper.floor(p.getZ() + Math.sin(a) * d);
            for (int dy = 4; dy >= -6; dy--) {
                BlockPos b = new BlockPos(x, p.getBlockY() + dy, z);
                if (w.getBlockState(b.down()).isSolidBlock(w, b.down())
                        && w.getBlockState(b).isAir() && w.getBlockState(b.up()).isAir() && w.getBlockState(b.up(2)).isAir()) {
                    MobEntity m = type.create(w);
                    if (m == null) return false;
                    m.refreshPositionAndAngles(b.getX() + 0.5, b.getY(), b.getZ() + 0.5, w.random.nextFloat() * 360f, 0f);
                    m.lookAtEntity(p, 360f, 360f);
                    w.spawnEntity(m);
                    if (m instanceof HostileEntity h) h.setTarget(p);
                    return true;
                }
            }
        }
        return false;
    }
}
