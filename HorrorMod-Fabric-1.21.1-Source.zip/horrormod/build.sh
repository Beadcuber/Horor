#!/usr/bin/env sh
set -eu
gradle build
printf '\nBuild complete: build/libs/horrormod-1.0.0.jar\n'
