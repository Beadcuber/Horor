# Horror Mod (Fabric — Minecraft 1.21.1)

A server-authoritative horror mod with three custom mobs, a craftable flashlight,
dark fog, ambient scares, and admin commands.

## Requirements
- Minecraft Java Edition **1.21.1**
- Fabric Loader **0.16.10 or newer**
- Fabric API **0.116.7+1.21.1** (or a compatible 1.21.1 Fabric API release)
- Java **21**
- Gradle **8.12** or newer

This project is specifically configured for 1.21.1. It is not a Minecraft 26.x build.

## Build
From this folder, run:

```bash
gradle build
```

On Windows, run `gradle build` from PowerShell or Command Prompt. The compiled mod
will be written to `build/libs/horrormod-1.0.0.jar`. Put that JAR and Fabric API
in the `mods` folder for both the client and dedicated server.

## Features
- **Cave Dweller:** aggressive cave stalker that is slowed and knocked back by the flashlight.
- **Herobrine:** watches from a distance and vanishes when stared at, approached, hit, or illuminated.
- **Fog Stalker:** freezes while a nearby player looks at it and pursues players when unseen.
- **Flashlight:** craft with iron, a glass pane, and redstone; right-click to toggle. The beam places a temporary light block and repels horror mobs.
- **Horror fog:** thickens at night, in dark areas, during rain, and near horror mobs. Press **H** to toggle it.
- **Random scares:** ambient sounds, footsteps, fake join/leave messages, torch removal, and Darkness.
- **Admin commands:** `/horror spawn <dweller|herobrine|stalker>`, `/horror event`, and `/horror intensity <0-10>`.

## Notes
- Commands require permission level 2 (operator).
- The flashlight and horror mobs are registered on the logical server; the fog and entity renderers are client-side.
- The mod does not add natural mob spawn rules; its horror encounters are triggered by the mod's per-player event system.
